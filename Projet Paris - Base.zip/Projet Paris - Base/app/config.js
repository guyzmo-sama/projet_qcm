// --------------------------------------------------------------------------------------------------------------------
// CONFIGURATION DE L'APPLICATION
// --------------------------------------------------------------------------------------------------------------------

const config = {
    // Configuration de la plateforme Firebase
    firebase: {
        // ...
    },
};


// La configuration est exportée afin d'être accessible par d'autres modules.
export default config;